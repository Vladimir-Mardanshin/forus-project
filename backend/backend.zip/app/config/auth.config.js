module.exports = {
    secret: "secret-word"
};